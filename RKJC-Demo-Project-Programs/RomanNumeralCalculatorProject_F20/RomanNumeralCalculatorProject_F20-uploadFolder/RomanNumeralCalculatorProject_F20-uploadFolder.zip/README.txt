Group members:
Richard Cross

Name of Project:
Roman Numeral Calculator

Description:
Calculator for working with Roman numerals

Usage Notes:
Requires clicking on one of the two entry fields and then using the roman numeral calculator key to enter a numb.
Click on the second entry bos and enter the second numeric input
Once both numbers have been entered click on the desired math function button.
Use the 'delere' to edit the imput if you make a mistake.

Installation Notes:
Requires the python numpy library
https://numpy.org/install/

